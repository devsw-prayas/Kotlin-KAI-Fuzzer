package io.kai.builders;

import io.kai.contracts.*;
import io.kai.contracts.capability.*;
import io.kai.scope.ScopeContext;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FunctionBuilder implements ITopLevelBuilder, IMemberBuilder,
        ILocalScopeBuilder, IContainer<ILocalScopeBuilder>, IGeneric {

    private final List<ILocalScopeBuilder> builders;
    private final String id;
    private final NameRegistry registry;
    private final Map<String, String> typeParams; // name -> bound
    private boolean isInline;
    private boolean isSuspend;

    private FunctionBuilder(List<ILocalScopeBuilder> builders, NameRegistry registry,
                            String id, Map<String, String> typeParams,
                            boolean isInline, boolean isSuspend) {
        this.builders = builders;
        this.registry = registry;
        this.id = id;
        this.typeParams = typeParams;
        this.isInline = isInline;
        this.isSuspend = isSuspend;
    }

    public FunctionBuilder(NameRegistry registry) {
        this.id = registry.next("fun");
        this.registry = registry;
        this.builders = new ArrayList<>();
        this.typeParams = new LinkedHashMap<>();
        this.isInline = false;
        this.isSuspend = false;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String build(int indentLevel) {
        String indent = indent(indentLevel);
        String body = builders.stream()
                .map(child -> indent(indentLevel + 1) + child.build(indentLevel + 1))
                .collect(Collectors.joining("\n"));

        StringBuilder prefix = new StringBuilder(indent);
        if (isSuspend) prefix.append("suspend ");
        if (isInline) prefix.append("inline ");
        prefix.append("fun ");

        String typeParamStr = buildTypeParams();
        if (!typeParamStr.isEmpty()) prefix.append(typeParamStr).append(" ");

        prefix.append(id).append("() {\n")
                .append(body).append("\n")
                .append(indent).append("}");

        return prefix.toString();
    }

    @Override
    public List<? extends IBuilder> children() {
        return builders;
    }

    @Override
    public void accept(IBuilderVisitor visitor) {
        visitor.visit(this);
        for (var child : builders) child.accept(visitor);
    }

    @Override
    @SuppressWarnings("SuspiciousMethodCalls")
    public IBuilder withoutChild(IBuilder builder) {
        ArrayList<ILocalScopeBuilder> list = new ArrayList<>(builders);
        list.remove(builder);
        return new FunctionBuilder(list, registry, id,
                new LinkedHashMap<>(typeParams), isInline, isSuspend);
    }

    @Override
    public boolean addChild(ILocalScopeBuilder builder) {
        if (builder == null) return false;
        return builders.add(builder);
    }

    @Override
    public boolean addChildren(List<ILocalScopeBuilder> children) {
        if (children.isEmpty()) return false;
        return builders.addAll(children);
    }

    @Override
    public void clear() {
        builders.clear();
    }

    // --- IGeneric ---

    @Override
    public boolean addTypeParam() {
        String name = registry.next("T");
        typeParams.put(name, "");
        return true;
    }

    @Override
    public boolean addBoundedTypeParam(String name, String bound) {
        if (typeParams.containsKey(name)) return false;
        typeParams.put(name, bound);
        return true;
    }

    @Override
    public Map<String, String> getTypeParams() {
        return typeParams;
    }

    @Override
    public boolean removeParam(String param) {
        return typeParams.remove(param) != null;
    }

    @Override
    public void clearParams() {
        typeParams.clear();
    }

    // --- Modifiers ---

    public void setInline(boolean inline) { this.isInline = inline; }
    public void setSuspend(boolean suspend) { this.isSuspend = suspend; }
    public boolean isInline() { return isInline; }
    public boolean isSuspend() { return isSuspend; }

    @Override
    public NameRegistry getRegistry() {
        return registry;
    }
}