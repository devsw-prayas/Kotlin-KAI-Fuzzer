package io.kai.builders;

import io.kai.contracts.IBuilder;
import io.kai.contracts.IBuilderVisitor;
import io.kai.contracts.NameRegistry;
import io.kai.contracts.Parameter;
import io.kai.contracts.capability.IContainer;
import io.kai.contracts.capability.IFirstStatement;
import io.kai.contracts.capability.ILocalScopeBuilder;
import io.kai.contracts.capability.ITopLevelBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ExtensionFunctionBuilder implements ITopLevelBuilder,
        IContainer<ILocalScopeBuilder>, IFirstStatement {
    private final String id;
    private final NameRegistry registry;
    private final String receiverType;
    private final List<Parameter> parameters;
    private final String returnType;
    private final List<ILocalScopeBuilder> body;
    private final List<String> annotations = new ArrayList<>();
    private String firstStatement = null;

    public ExtensionFunctionBuilder(NameRegistry registry, String receiverType) {
        this.registry = registry;
        this.id = registry.next("ext_fun");
        this.receiverType = receiverType;
        this.parameters = new ArrayList<>();
        this.returnType = "Unit";
        this.body = new ArrayList<>();
    }

    private ExtensionFunctionBuilder(NameRegistry registry, String id, String receiverType,
                                     List<Parameter> parameters, String returnType,
                                     List<ILocalScopeBuilder> body) {
        this.registry = registry;
        this.id = id;
        this.receiverType = receiverType;
        this.parameters = new ArrayList<>(parameters);
        this.returnType = returnType;
        this.body = new ArrayList<>(body);
    }

    @Override
    public String id() { return id; }

    @Override
    public String build(int indentLevel) {
        String indent = indent(indentLevel);
        String paramsStr = parameters.stream()
                .map(p -> p.name() + ": " + p.type())
                .collect(Collectors.joining(", "));
        StringBuilder bodyBuilder = new StringBuilder();
        if (firstStatement != null) {
            bodyBuilder.append(indent(indentLevel + 1))
                    .append(firstStatement).append("\n");
        }
        bodyBuilder.append(body.stream()
                .map(s -> indent(indentLevel + 1) + s.build(indentLevel + 1))
                .collect(Collectors.joining("\n")));
        String bodyStr = bodyBuilder.toString();

        StringBuilder sb = new StringBuilder();
        for (String ann : annotations) {
            sb.append(indent).append(ann).append("\n");
        }
        sb.append(indent);
        sb.append("fun ").append(receiverType).append(".").append(id)
                .append("(").append(paramsStr).append("): ").append(returnType)
                .append(" {\n");
        if (!bodyStr.isEmpty()) sb.append(bodyStr).append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

    @Override
    public List<? extends IBuilder> children() { return body; }

    @Override
    public void accept(IBuilderVisitor visitor) {
        visitor.visit(this);
        for (var s : body) s.accept(visitor);
    }

    @Override
    @SuppressWarnings("SuspiciousMethodCalls")
    public IBuilder withoutChild(IBuilder builder) {
        List<ILocalScopeBuilder> newBody = new ArrayList<>(body);
        newBody.remove(builder);
        ExtensionFunctionBuilder copy = new ExtensionFunctionBuilder(registry, id, receiverType,
                parameters, returnType, newBody);
        annotations.forEach(copy::addAnnotation);
        copy.setFirstStatement(firstStatement);
        return copy;
    }

    @Override
    public boolean addChild(ILocalScopeBuilder builder) {
        if (builder == null) return false;
        return body.add(builder);
    }

    @Override
    public void clear() { body.clear(); }

    public void addParam(Parameter p) {
        if (p != null) parameters.add(p);
    }

    @Override
    public NameRegistry getRegistry() { return registry; }

    public String getReceiverType() { return receiverType; }
    public String getReturnType() { return returnType; }
    public List<Parameter> getParameters() { return parameters; }

    public void addAnnotation(String raw) {
        if (raw != null && !annotations.contains(raw)) annotations.add(raw);
    }

    public List<String> getAnnotations() { return annotations; }

    @Override
    public void setFirstStatement(String stmt) { this.firstStatement = stmt; }

    @Override
    public String getFirstStatement() { return firstStatement; }

    @Override
    public boolean hasFirstStatement() { return firstStatement != null; }
}