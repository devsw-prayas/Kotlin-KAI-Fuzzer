package io.kai.contracts.capability;

public interface IFirstStatement {
    void setFirstStatement(String stmt);
    String getFirstStatement();
    boolean hasFirstStatement();
}